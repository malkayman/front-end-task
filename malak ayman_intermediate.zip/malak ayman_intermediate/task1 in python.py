def find_longest_string(strings):
    if not strings:
        return None
    
    longest_string = max(strings, key=len)
    return longest_string

case1 = ["apple", "banana", "pear", "kiwi"]
result1 = find_longest_string(case1)
print(result1)  


case2 = []
result2 = find_longest_string(case2)
print(result2)  