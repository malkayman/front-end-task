
function outer() {
    let A = "Hello front end";
   
   
       function inner() {
           console.log(A);
       }
   
   
       return inner;
   }
   let closure = outer();
   closure();