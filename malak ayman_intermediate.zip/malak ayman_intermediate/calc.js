let display = document.getElementById('display');

function DisplayButton(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function equals() {
    try {
        display.value = eval(display.value);
    } catch (error) {
        display.value = 'Error';
    }
}