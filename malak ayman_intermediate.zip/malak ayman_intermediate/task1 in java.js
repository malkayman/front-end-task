function findLongestString(arr) {
    if (arr.length === 0) {
        return null;
    }

    let longestString = arr[0];

    for (let i = 1; i < arr.length; i++) {
        if (arr[i].length > longestString.length) {
            longestString = arr[i];
        }
    }

    return longestString;
}


const case1 = ["apple", "banana", "pear", "kiwi"];
console.log(findLongestString(case1));  


const case2 = [];
console.log(findLongestString(case2));  